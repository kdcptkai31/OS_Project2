# OS_Project2
______________________________________________________________________________

### Group Members:
* Cody Thompson 
  * cthomp3219@gmail.com
  * Section 2
* Kai Duty
  * kdcptkai31@gmail.com
  * Section 3
* Ryley Webber
  * riley.webber@gmail.com
  * Section 2
 ______________________________________________________________________________________________________________________________

### Language Used:
* C++
* C

____________________________________________________________________________
### How to Execute:
Open a terminal and navigate to the project directory.  Once there, run the make commands as seen in the "Special Instructions" section.
Then type "./main" to run it. Follow the prompts from there on out.

______________________________________________________________________________________________________________________________

### Bonus:
N/A

______________________________________________________________________________________________________________________________

### Special Instructions: 
In the respective directory, run "make clean" followed by "make all".  These commands will remove any object files and executables within the project directory and then create new ones. Running "make tar" will create the tar file.

______________________________________________________________________________________________________________________________

### Screen Shots:
![Alt text](execution.png?raw=true "Optional Title")
![Alt text](execution2.png?raw=true "optional Title")

_______________________________________________________________________________________________________________________________

### Contributions:
All group members consulted each other whenever questions arose.
Additionally, we all peer programed together with zoom screen sharing,
so the group's efforts are completely split evenly.

_______________________________________________________________________________________________________________________________
